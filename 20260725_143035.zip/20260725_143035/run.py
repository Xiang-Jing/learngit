"""自动生成（结构化版）—— 业务参数驱动：入口 / 代码列表 / 指标列表。
来源 recording: 20260725_143035
目标应用: Choice.exe
参数: 改同目录 params.json —— JSON 列表，每个元素一组参数，逐组执行：
  [{"entry": "ede",
    "codes": ["代码1", "代码2", ...],
    "indicators": [
      {"name": "指标名(仅日志)", "query": "搜索词",
        "params": {"报告期": "..."} },
      ...
    ]}]
- indicators 数量/顺序随意；params 的键=编辑器**行标签**（收费类型/交易日期/
  报告期…），按键序逐行操作后点确定——编辑器种类/变体无关，找不到标签或
  选项会明确报错，不会乱点。
- 值可为**列表**：复合组按序应用，如 "报告期": ["2025", "年报"]（年份下拉
  选 2025，报告类型下拉选 年报）。
- params 为空/缺省 = 该指标没有参数编辑器（添加后不弹框）。
- 无 params.json 时按录制原样回放（RECORDED_INDICATORS）。
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
for _p in HERE.parents:
    if (_p / "rpa").is_dir():
        if str(_p) not in sys.path:
            sys.path.insert(0, str(_p))
        break

from rpa.runtime import Bot

PARAMS_FILE = Path(__file__).with_name("params.json")
RECORDING_DIR = Path(__file__).with_name("recordings")

RECORDED_INDICATORS = [   # 录制时的指标序列（无 params.json 时按此回放）
    {"query": 'meigu zhuanz gub ', "params": {'报告期': ['2025', '年报', '确定']}},
    {"query": 'shifou fenhong ', "params": {'报告期': '2025'}},
]


def load_params():
    if PARAMS_FILE.exists():
        rows = json.loads(PARAMS_FILE.read_text(encoding="utf-8"))
        if isinstance(rows, dict):
            rows = [rows]
        if rows:
            return rows
    return [{}]                     # 无参数文件：按录制时的默认值跑一遍


def _vals(v):
    """参数值可为单值或列表：列表 = 逐个「键入+回车」。"""
    return list(v) if isinstance(v, (list, tuple)) else [v]


def apply_editor(bot, params):
    """参数编辑器通用操作：按 params 键序逐行 bot.edit_row（键=行标签，
    实时 OCR 定位；值可为列表——复合组如 报告期=["2025","年报"]），
    最后点确定。编辑器种类/变体无关。"""
    bot.wait(3000)
    for _k, _v in params.items():
        bot.edit_row(_k, _v)
    bot.wait(2793)
    bot.click(ocr='确定', ocr_off=(-7, 2), anchor='ocr_16.png', anchor_at=(170, 75), image='tpl_16.png', img_off=(-7, 2), win_class='Qt5QWindowIcon', win_rect=(807, 284, 1111, 740), win_dpi=96, rel=(0.6053, 0.9627), raw=(991, 723))  # [16] 确定

def add_indicator(bot, query=None, params=None, name=None, **_extra):
    """添加一个指标：搜索→回车选中→（有 params 时）操作参数编辑器。"""
    query = query or name
    if not query:
        raise RuntimeError('indicator 缺少 query/name')
    print(f'—— 指标: {name or query} ——')
    bot.wait(1921)
    bot.click(ocr='输入拼音查找指标：', ocr_off=(-12, -3), anchor='ocr_09.png', anchor_at=(43, 75), image='tpl_09.png', img_off=(-14, -3), win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96, rel=(0.0263, 0.6013), raw=(43, 627))  # [9] 输入拼音查找指标：
    bot.wait(3000)
    for _v in _vals(query):  # [10]
        bot.type(_v, win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96)
        bot.wait(3000)
        bot.key('enter')  # [11]
    if params:
        apply_editor(bot, params)

def run_once(entry='ede', codes=None, indicators=None):
    bot = Bot(process='Choice.exe', recording_dir=str(RECORDING_DIR))
    bot.activate(title_re='Choice金融终端.*', class_name='Qt5QWindowIcon')
    bot.click(ocr='^中拼', ocr_off=(-9, -32), ocr_from='left', anchor='ocr_01.png', anchor_at=(170, 75), image='tpl_01.png', img_off=(-77, -32), win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96, rel=(0.8507, 0.9792), raw=(1639, 1026))  # [1] ^中拼
    bot.wait(832)
    for _v in _vals(entry):  # [2]
        bot.type(_v, win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96)
        bot.wait(1656)
        bot.key('enter')  # [3]
    bot.wait(3000)
    bot.click(ocr='24小时直播：火欧盟再次面临巨额关税', ocr_off=(-59, -47), anchor='ocr_04.png', anchor_at=(76, 75), image='tpl_04.png', img_off=(-57, -47), win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96, rel=(0.0434, 0.9356), raw=(76, 980))  # [4] 24小时直播：火欧盟再次面临巨额关税
    bot.wait(1012)
    for _c in _vals(codes if codes is not None else ['688697', '688008']):
        bot.type(_c, win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96)
        bot.wait(1946)
        bot.key('enter')
    for _ind in (indicators if indicators is not None else RECORDED_INDICATORS):
        add_indicator(bot, **_ind)
    bot.wait(2351)
    bot.click(ocr='提取数据', ocr_off=(-4, 0), ocr_from='left', anchor='ocr_25.png', anchor_at=(170, 75), image='tpl_25.png', img_off=(-30, 0), win_class='Qt5QWindowIcon', win_rect=(-8, -8, 1928, 1048), win_dpi=96, rel=(0.1534, 0.1174), raw=(289, 116))  # [25] 提取数据

def run():
    rows = load_params()
    fails = []
    for i, row in enumerate(rows, 1):
        print(f"=== [{i}/{len(rows)}] 参数组 {i} ===")
        try:
            run_once(**{k: row[k] for k in ("entry", "codes", "indicators") if k in row})
        except Exception as e:
            print(f"!!! 第 {i} 组失败: {e!r}")
            fails.append(i)
    print(f"完成: {len(rows) - len(fails)} 成功 / {len(fails)} 失败"
          + (f"(第 {fails} 组)" if fails else ""))


if __name__ == "__main__":
    run()
